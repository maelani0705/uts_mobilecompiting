package limfiq.inc.crudmysql;

public class ServerAPI {
    public static final String URL_DATA = "http://192.168.43.153/mobile2/uts/view_data.php";
    public static final String URL_INSERT = "http://192.168.43.153/mobile2/uts/create_data.php";
    public static final String URL_DELETE = "http://192.168.43.153/mobile2/uts/delete_data.php";
    public static final String URL_UPDATE = "http://192.168.43.153/mobile2/uts/update_data.php";
}
